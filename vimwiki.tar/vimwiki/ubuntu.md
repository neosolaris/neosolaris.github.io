---
title: Ubuntu
date : 2022-08-23T18:35:04+09:00
lastmod: 2022-08-23T18:53:33+09:00 
tags: ["linux", "ubuntu"]
categories: ["linux"]
---

