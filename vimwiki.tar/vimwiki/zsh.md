---
title: Zsh
date : 2022-08-23T18:35:04+09:00
lastmod: 2022-08-26T02:51:28+09:00
tags: ["shell","zsh","linux"]
categories: ["linux"]
---

* [zsh install](zsh-install) - zsh 설치 및 설정
