---
title: Pyfits - Python FITS Module
date: 2022-10-11T18:16:24+09:00
lastmod:
tags:
categories:
---

* 이것 또한 현재 관리되고 있지 않다.
* [astropy](astropy)에 통합되어 관리된다.
* 결론은 파이썬에서는 [astropy](astropy)만 집중하면 된다.


