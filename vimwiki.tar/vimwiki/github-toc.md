---
title: Github toc
date : 2022-08-23T18:35:04+09:00
lastmod:
tags:
categories:
---
# GitHub TOC 만들기

## 방법
* 다음처럼 작성하면 된다.

```
# My menu 
	* [목차1][home] 
	* [목차2][techdocs] 
	* [목차3][usermanual] 

[home]: https://github.com/myproject/wiki/목차1 
[techdocs]: https://github.com/myproject/wiki/목차2 
[usermanual]: https://github.com/myproject/wiki/목차3
```

## Reference
* [Github Wiki에서 TOC 만들기](https://ruby-kim.github.io/2022/04/07/Hexo/Install/)
