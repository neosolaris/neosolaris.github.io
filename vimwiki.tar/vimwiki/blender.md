---
title: Blender
date: 2022-08-29T17:53:06+09:00
lastmod: 2022-08-29T17:53:29+09:00
tags: ["blender"]
categories: ["3d-modeling"]
---

* [blender install](blender-install)
* [blender touchpad](blender-touchpad)
