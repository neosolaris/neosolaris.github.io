---
title: Graphic Card - 그래픽카드
date: 2023-09-19T18:23:49+09:00
lastmod:
tags: ['graphic','card']
categories: ['hardware']
---

## Nvidia Quadro 5000
* 최신 드라이버 설치: windows 10, 11
* dp 연결: 그래픽 출력의 최적은 현재로서는 dp이다.
    - dp선을 연결
    - 다른 선이 있을 경우 제거하면 디폴트로 화면 출력이 된다.
