---
title: Firefox
date : 2022-08-23T18:35:04+09:00
lastmod: 2023-08-26T17:25:52+09:00
tags: ["browser", "firefox"]
categories: ["www"]
---

## Install & Setup
* [ubuntu firefox](ubuntu-firefox) - 우분투에서 파이어폭스 설치

## Plugins
* [Markdown Viewer Webext](markdown-viewer-webtext) - 로컬의 마크다운 파일을 html로 보기
* [vimium c](vimium-c) - vim 명령어 환경으로 파이어폭스 사용하기
