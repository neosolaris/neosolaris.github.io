---
title: Vis - Structural Regular Expressions
date: 2022-12-07T07:26:00+09:00
lastmod:
tags: ['vis','re']
categories: ['editor']
---

## Intro

## Tutorial Sam Command Language

## Links
* sam structural regular expression <http://doc.cat-v.org/bell_labs/structural_regexps/se.pdf>
* sam command tutorial <http://doc.cat-v.org/bell_labs/sam_lang_tutorial/sam_tut.pdf>
