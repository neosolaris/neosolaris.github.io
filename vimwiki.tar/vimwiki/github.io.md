---
title: Github Page
date: 2022-08-24T00:44:36+09:00
lastmod:
tags: ["github","git"]
categories: ["www"]
---                                                                         
 
* [github](github)에서 무료로 제공하는 개발자용 홈페이지이다.
* 예를 들어 `github.com/user_name`의 계정을 가지고 있다면 `https://user_name.github.io`의 도메인 이름으로 자신의 홈페이지를 개설할 수 있다.
* github에 `user_name.github.io`라는 저장소를 새로 생성하고 공개(public)하면 바로 사용할 수 있다.
* README.md < index.md < index.html 우선권 순서로 동작한다.
* 처음 테스트 파일을 깃허브에 올린 후 브라우저에서 2-3분 후 확인 가능하다.
