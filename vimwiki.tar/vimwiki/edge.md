---
title: Edge - 윈도우즈 브라우저
date: 2023-09-08T15:13:16+09:00
lastmod:
tags: ['www', 'windows','browser']
categories: ['www']
---

* 이것을 사용하는 이유는 어쩔 수 없이 관공서나 금융권 때문이다.
* 한국의 후진적인 공인인증서제도와 윈도우즈 중심 사용으로 인한 폐해가 아닐까 한다.

## 다크모드 Dark mode 변경
* 모양변경: 설정 > 브라우저 디스플레이> 모양 사용자 지정 > 어둡게
* 웹페이지변경: 브라우저 창에 다음과 같이 입력 후 재실행
```
edge://flags/#enable-force-dark
```

