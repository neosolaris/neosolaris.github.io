---
title: TODO
date: 2022-08-24T02:35:08+09:00
lastmod: 2022-09-12T02:36:40+09:00
tags: ["todo"]
categories: ["etc"]
---                                                                         

## 2023-08
* [X] 2023-08-07: openrc, doas 문서 정리, 업로드
* [X] 2023-08-06: [vimwiki hugo github](vimwiki-hugo-github): 프로젝트를 자동 업데이트하도록 nvim 추가
* [X] 2023-08-06: blogen.lua: 수정: vimwiki-hugo와 githubio 모두 git push 하도록 수정 nvim에 <F8> 등록, <F5>는 ~/git/* git pull
* [X] 2023-08-05: blogen.lua 스크립트 nvim내 실행시 출력 깨지는 문제 해결
* [X] 2023-08-03: windows wsl + alpine + docker + git 설치 완료 및 문서 정리

## 2022-09
* [X] 2022-09-08
    - [X] nvim에서 왜 autosave가 되지 않는가
    - [X] [nvim lua](nvim-lua) 공부
    - [X] [lua](lua) 공부 계속
* [X] 2022-09-02
    - [X] [nvim lua](nvim-lua) 공부
    - [X] [lua](lua) 공부 계속
    - [X] [ssh keygen](ssh-keygen) 문서 정리
* [X] 2022-09-01
    - [X] [yadm](yadm) 설치 및 설정, 문서 정리
    - [X] [lua](lua) 공부 계속

## 2022-08

* [X] 2022-08-31
	- [X] [rclone](rclone) 설치 및 설정 그리고 문서 정리
* [X] 2022-08-26
	- [X] nvim lua 공부
	- [X] www 프로젝트 문서 업데이트
    - [X] hugo project: blog.sh 링크 필터링 부분 수정
* [X] 2022-08-25
	- [X] nvim 플러그인 공부
	- [X] www 프로젝트 문서 업데이트
* [X] 2022-08-24
	- [X] vim 공부
	- [X] www 프로젝트 문서 업데이트
	- [X] generate.sh 파일명 수정: blog.sh {gen|push} 그리고 ~/bin 링크
* [X] 2022-08-23
	- [X] [vimwiki](vimwiki) 문서 정리
	- [X] 깃허브에 만든 블로그 올리고 테스트
	- [X] www 프로젝트 정리하고 수정 보완
	- [X] [papermod](hugo-papermod) 에 lastmod 표시하기
	- [X] [vim](vim) 에 abbr 추가 및 설정: generate.sh 실행
