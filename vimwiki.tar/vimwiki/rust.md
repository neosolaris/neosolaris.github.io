---
title: Rust Programming Language
date : 2022-08-23T18:35:04+09:00
lastmod: 2022-08-31T16:58:35+09:00
tags: ["rust","language","prgramming"]
categories: ["language","devel"]
---

* [rust install](rust-install) - 러스트 설치
* [rust compile size](rust-compile-size) - 컴파일 사이즈 줄이기
