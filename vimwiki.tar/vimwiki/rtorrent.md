---
title: Rtorrent - 설치 및 사용법
date: 2022-10-26T18:13:39+09:00
lastmod:
tags: ['rtorrent','utils']
categories: ['utils']
---

## Install
```console
$ sudo apt install rtorrent
```

## Usage
```console
$ cd ~/Downloads   # 현재 폴더로 다운로드됨
$ rtorrent <torrent_filename>.torrent  # 다운로드
Control + q        # 종료
```

## Links
<https://www.usessionbuddy.com/post/How-to-setup-and-use-rtorrent-on-Linux/>
