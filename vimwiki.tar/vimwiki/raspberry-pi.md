---
title: Raspberry Pi 라즈베리파이
date : 2022-08-23T18:35:04+09:00
lastmod: 2023-08-26T16:54:31+09:00
tags: ["pi","hardware"]
categories: ["hardware","linux"]
---

- [raspbian update](raspbian-update) - Update Raspbian from an Older Version to Buster

