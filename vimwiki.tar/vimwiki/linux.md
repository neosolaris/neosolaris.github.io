---
title: Linux
date: 2022-09-03T01:39:14+09:00
lastmod: 2022-09-15T21:46:22+09:00
tags: ["linux"]
categories: ['linux']
---

* Ubuntu
  * [ubuntu install](ubuntu-install) - 우분투 설치
  * [ubuntu firefox](ubuntu-firefox) - 우분투에서 파이어폭스 설치

* Archlinux
  * [archlinux install](archlinux-install)
  
* Alpine
  * [alpine lua language server](alpine-lua-language-server)
