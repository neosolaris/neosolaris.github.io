---
title: Astropy - 파이썬 천문학 모듈
date: 2022-10-11T23:44:34+09:00
lastmod:
tags: ['fits','python','astropy']
categories: ['graphic','astronomy']
---

## Intro
* 그간 과학자들이 사용해왔던 fits 관련 툴들을 바이딩하고 통합한 모듈이다.
* anaconda에서 기본 설치된다.
* 이를 이용하는 것이 의존성을 신경 쓰지 않고 쉽게 사용하는 방법이다.
* 그러나 anaconda는 1.6기가 정도 된다. 엄청나다.

## Links
* [천문학 데이터 파일 형식 FITS 파일형식 다루기](https://himbopsa.tistory.com/33)
