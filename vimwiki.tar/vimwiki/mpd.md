---
title: MPD Music Player Daemon
date : 2022-08-23T18:35:04+09:00
lastmod: 2022-08-24T03:52:09+09:00 
tags: ["mpd","music"]
categories: ["linux","music"]
---

## Mpd Clients CLI
* [mpc](mpc) : 가장 간단한 프로그램
* [mmtc](mmtc) : [rust](rust) 로 작성된 심플한 프로그램
* [ncmpc](ncmpc) : c++로 작성, ncurse를 이용한 프로그램
* [ncmpcpp](ncmpcpp) : ncmpc를 더욱 발전시킴, 제일 기능이 많고 편하고 마음에 든다.
