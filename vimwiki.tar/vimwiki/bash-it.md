---
title:  bash-it
date: 2022-08-26T22:43:57+09:00
lastmod:
tags: ["bash","plugin"]
categories: ["shell"]
---                                                                         

* 다음 링크 참조
<https://www.linuxfordevices.com/tutorials/linux/fancify-bash-terminal-with-bash-it>
