---
title: Bash
date: 2022-08-26T21:54:04+09:00
lastmod:
tags: ["shell","bash"]
categories: ["shell"]
---                                                                         

* Tools, Functions
	* [bash it](bash-it) : zsh처럼 이쁘게, 다양한 기능으로 꾸미기
  * [bash color](bash-color) : 터미널 컬러 출력 및 제어

* Bash Programming
	* [bash read lines](bash-read-lines) : 파일에서 한 줄씩 라인을 읽어 오기

## Links
* bash config files <https://floatingoctothorpe.uk/2018/bash-config-and-where-it-lives.html>
