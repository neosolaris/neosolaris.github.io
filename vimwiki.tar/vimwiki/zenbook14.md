---
title: Zenbook14
date : 2022-08-23T18:35:04+09:00
lastmod: 2022-08-24T04:00:56+09:00
tags: ["zenbook","notebook","hardware"]
categories: ["hardware"]
---

## 노트북 사양

* ASUS 젠북 14 UM3402YA-KP095W

```
노트북 / 운영체제(OS) : 윈도우11홈 / 일반유통상품 / 용도 : 사무/인강용 , 휴대용 /
화면정보 35.56cm(14인치) / 2560x1600(WQXGA) / sRGB : 100% / 400nit / IPS / 광시야각 / 슬림형 베젤 /
프로세서 AMD / 라이젠7-4세대 / 바르셀로 / 5825U (2.0GHz) / 옥타코어 /
메모리 LPDDR4x(온보드) / 메모리 용량 : 16GB / 메모리 교체: 불가능 /
저장장치 M.2(NVMe) / 512GB /
그래픽 내장그래픽 / Radeon Graphics /
네트워크 무선랜: 802.11ax(Wi-Fi 6E) /
영상입출력 HDMI 2.0 / 웹캠(HD) /
단자 USB-C: 2개 / USB-A: 1개 / USB 3.2 / MicroSD카드 /
부가기능 지문인식(전원버튼) / USB-PD / DP Alt Mode / MIL-STD / 리프트 힌지 /
입력장치 키보드 라이트 / ㅗ형 방향키 /
파워 배터리 : 75Wh / 어댑터 : 65W / 충전단자 : 타입C /
주요제원 두께 : 16.9mm / 무게 : 1.39kg / 색상: 블랙
```

## OS 설치 환경

* [윈도우11](windows11)
* [우분투 22.04](ubuntu)
